
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './pages/Dashboard';
import { Login } from './pages/Login';
import { Candidates } from './pages/Candidates';
import { JobProfiles } from './pages/JobProfiles';
import { SubmitApplication } from './pages/SubmitApplication';
import { AdminSettings } from './pages/AdminSettings';
import { Interviews } from './pages/Interviews';
import { Reports } from './pages/Reports';
import { PublicAssessment } from './pages/PublicAssessment';
import { JobBoard } from './pages/JobBoard'; 
import { User } from './types';
import { apiService } from './services/apiService';

const ProtectedLayout: React.FC<{ children: React.ReactNode; user: User | null; onLogout: () => void }> = ({ children, user, onLogout }) => {
  if (!user) return <Navigate to="/" replace />; 
  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar user={user} onLogout={onLogout} />
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    apiService.logSystemAction(loggedInUser, 'User Login', `User: ${loggedInUser.name}`, 'Successful authentication');
  };

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <Router>
      <Routes>
        <Route path="/assess/:formId/:candidateId" element={<PublicAssessment />} />
        <Route path="/careers" element={<JobBoard />} />
        
        <Route path="/" element={!user ? <Login onLogin={handleLogin} /> : <ProtectedLayout user={user} onLogout={handleLogout}><Dashboard /></ProtectedLayout>} />
        <Route path="/candidates" element={!user ? <Navigate to="/" /> : <ProtectedLayout user={user} onLogout={handleLogout}><Candidates user={user} /></ProtectedLayout>} />
        <Route path="/jobs" element={!user ? <Navigate to="/" /> : <ProtectedLayout user={user} onLogout={handleLogout}><JobProfiles user={user} /></ProtectedLayout>} />
        <Route path="/interviews" element={!user ? <Navigate to="/" /> : <ProtectedLayout user={user} onLogout={handleLogout}><Interviews user={user} /></ProtectedLayout>} />
        <Route path="/reports" element={!user ? <Navigate to="/" /> : <ProtectedLayout user={user} onLogout={handleLogout}><Reports /></ProtectedLayout>} />
        <Route path="/submit" element={!user ? <Navigate to="/" /> : <ProtectedLayout user={user} onLogout={handleLogout}><SubmitApplication /></ProtectedLayout>} />
        
        <Route path="/admin" element={
          !user ? <Navigate to="/" /> : (
            <ProtectedLayout user={user} onLogout={handleLogout}>
              {user.role === 'admin' || user.role === 'super_admin' ? <AdminSettings /> : <Navigate to="/" />}
            </ProtectedLayout>
          )
        } />
        
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
};

export default App;
