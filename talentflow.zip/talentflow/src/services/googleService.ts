import { Interview, Candidate } from '../types';

/**
 * Service to handle Google Workspace Integrations.
 * In a production app, this would interact with a backend that manages OAuth2 tokens.
 * Here we structure the payloads and mock the API responses to simulate the integration.
 */
class GoogleService {
  
  /**
   * Generates a Google Meet link and simulates creating a Calendar event.
   */
  async createCalendarEvent(
    interview: Partial<Interview>, 
    attendeeEmails: string[]
  ): Promise<{ eventId: string; meetLink: string }> {
    
    // 1. Construct the GCal API Payload (Reference for backend implementation)
    const eventPayload = {
      summary: `Interview: ${interview.candidateName} - ${interview.type}`,
      description: `Interview for ${interview.jobTitle}. Notes: ${interview.notes}`,
      start: {
        dateTime: interview.date, // ISO String
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      end: {
        dateTime: new Date(new Date(interview.date!).getTime() + 60 * 60 * 1000).toISOString(), // 1 hour duration
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      attendees: attendeeEmails.map(email => ({ email })),
      conferenceData: {
        createRequest: {
          requestId: `req-${Date.now()}`,
          conferenceSolutionKey: { type: "hangoutsMeet" },
        },
      },
    };

    console.log('[GoogleService] Creating Calendar Event with payload:', eventPayload);

    // 2. Simulate API Call delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // 3. Return Mocked Response
    // In production: const response = await gapi.client.calendar.events.insert(...)
    return {
      eventId: `gcal_evt_${Date.now()}`,
      meetLink: `https://meet.google.com/abc-${Math.floor(Math.random()*1000)}-xyz`
    };
  }

  /**
   * Sends an email via Gmail API.
   */
  async sendGmail(to: string, subject: string, body: string): Promise<boolean> {
    
    // 1. Construct RFC 822 Message
    const emailLines = [
      `To: ${to}`,
      "Subject: " + subject,
      "Content-Type: text/plain; charset=utf-8",
      "",
      body
    ];
    const email = emailLines.join("\r\n").trim();
    // const base64EncodedEmail = btoa(email).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

    console.log('[GoogleService] Sending Gmail to:', to);
    
    // 2. Simulate API Call delay
    await new Promise(resolve => setTimeout(resolve, 800));

    // In production: await gapi.client.gmail.users.messages.send({ userId: 'me', resource: { raw: base64EncodedEmail } })
    return true;
  }

  /**
   * Scrapes/Parses a public profile URL (LinkedIn/JobStreet).
   * Note: Real implementation requires a backend scraper or official API partnership.
   */
  async sourceCandidateProfile(url: string): Promise<Partial<Candidate>> {
    console.log('[GoogleService] Sourcing from:', url);
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Mock scraping logic based on URL pattern
    const isLinkedIn = url.includes('linkedin.com');
    
    return {
      name: isLinkedIn ? "Sourced LinkedIn User" : "Sourced Candidate",
      skills: ["Sourced Skill 1", "Sourced Skill 2"],
      jobHistorySummary: `Imported profile from ${url}`,
      educationSummary: "See attached profile link",
      sourceUrl: url,
      // Status starts as New
      status: 'New'
    };
  }
}

export const googleService = new GoogleService();