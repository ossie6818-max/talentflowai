
export enum LoadingStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export type Role = 'super_admin' | 'admin' | 'requestor' | 'verifier' | 'approver' | string;
export type Department = string; 
export type JobSeniority = string;

export interface DepartmentInfo {
  id: string;
  name: string;
}

export interface OrganizationSettings {
  companyName: string;
  accountNumber: string;
  address: string;
  logoUrl?: string;
  accessTier: 'Starter' | 'Growth' | 'Enterprise';
  primaryContactEmail: string;
  taxId?: string;
}

export interface EvaluationCriteria {
  id: string;
  category: string;
  description: string;
  weight: 'low' | 'medium' | 'high';
}

export interface JobProfile {
  id: string;
  title: string;
  department: Department;
  seniority: JobSeniority;
  description: string;
  requirements: string[];
  certifications: string[];
  location: string;
  createdAt: string;
  createdBy: string;
  status: 'Draft' | 'Pending Approval' | 'Active' | 'Archived' | 'Rejected';
  evaluationCriteria: EvaluationCriteria[];
  assignedVerifier?: string;
  assignedApprover?: string;
}

export interface AuditLog {
  id: string;
  action: string;
  details: string;
  actorName: string;
  timestamp: string;
}

export interface SystemAuditLog {
  id: string;
  actorName: string;
  action: string;
  target: string; 
  details: string;
  timestamp: string;
  ipAddress?: string;
}

export interface Scorecard {
  id: string;
  interviewerName: string;
  overallRating: number;
  feedback: string;
  competencyScores: { criteriaId: string; score: number }[];
  submittedAt: string;
}

// NEW: Attachment Interface for multi-file support
export interface Attachment {
  id: string;
  name: string;
  type: 'CV' | 'Cover Letter' | 'Portfolio' | 'Certificate' | 'ID Scan' | 'Other';
  url: string;
  uploadedAt: string;
}

export interface Candidate {
  id: string;
  referenceNumber: string;
  name: string;
  email: string;
  phone?: string;
  city?: string;
  birthdate?: string;
  jobId: string;
  department?: Department;
  skills: string[];
  educationSummary: string;
  jobHistorySummary: string;
  previousApplicationDeclared: boolean;
  previousApplicationDetails?: string;
  aiScore: number;
  aiConsideration: string;
  status: 'New' | 'Reviewing' | 'Interview' | 'Offer' | 'Pending Hired' | 'Rejected' | 'Hired';
  // Deprecated single string in favor of array, keeping for backward compat if needed
  cvUrl?: string; 
  attachments: Attachment[]; // NEW: Multiple attachments
  submissionDate: string;
  auditLogs?: AuditLog[];
  scorecards?: Scorecard[];
  credentialsMatch?: boolean;
  sourceUrl?: string; // NEW: Origin URL (LinkedIn etc)
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  department: Department;
  avatar?: string;
  status: 'Active' | 'Inactive';
}

export interface RolePermissions {
  canCreateJobs: boolean;
  canApproveJobs: boolean;
  canViewAllCandidates: boolean; 
  canViewDepartmentCandidates: boolean; 
  canManageUsers: boolean;
  canConfigureWorkflows: boolean;
  canViewSensitiveData: boolean;
  canShortlistCandidates: boolean; 
  canAdvancePipelineStages: boolean; 
  canProposeHiring: boolean; 
  canApproveHiring: boolean; 
}

export interface RoleDefinition {
  role: Role;
  label: string;
  description: string;
  permissions: RolePermissions;
  isCustom?: boolean;
}

export interface PendingRoleRequest {
  id: string;
  name: string;
  description: string;
  requestedBy: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  permissions: RolePermissions;
}

export interface SeniorityLevel {
  id: string;
  label: string;
  level: number;
}

export interface Interview {
  id: string;
  candidateId: string;
  candidateName: string;
  jobTitle: string;
  date: string;
  type: 'Phone Screen' | 'Technical' | 'Cultural Fit' | 'Final';
  interviewers: string[];
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  notes?: string;
  meetingLink?: string;
  googleCalendarEventId?: string; // NEW: Link to GCal
  location?: string;
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body: string;
  type: 'Invitation' | 'Rejection' | 'Offer' | 'General';
}

export interface FormTemplate {
  id: string;
  title: string;
  description: string;
  questions: { id: string; type: 'text' | 'rating' | 'choice'; label: string }[];
}

export interface FormResponse {
  questionId: string;
  questionLabel: string;
  answer: string | number;
}

export interface FormSubmission {
  formId: string;
  candidateId: string;
  responses: FormResponse[];
  submittedAt: string;
}

export interface SentForm {
  id: string;
  formTemplateId: string;
  formTitle: string;
  candidateId: string;
  sentDate: string;
  status: 'Sent' | 'Completed';
  publicLink?: string;
  submission?: FormSubmission;
  aiScore?: number;
  aiEvaluation?: string;
}

export interface ReportFilter {
  dateRange: 'week' | 'month' | 'quarter' | 'year';
  department: string;
  reportType: 'pipeline' | 'demographics' | 'performance';
}

export interface ReportData {
  pipelineFunnel: { stage: string; count: number }[];
  hiresOverTime: { date: string; hires: number }[];
  departmentDistribution: { name: string; value: number }[];
  seniorityDistribution: { name: string; value: number }[];
  positionDistribution: { name: string; value: number }[];
  timeToHire: number; 
  totalApplications: number;
  offerAcceptanceRate: number; 
}

// NEW: Sourcing Types
export interface SourcedProfile {
  name: string;
  currentRole?: string;
  skills: string[];
  profileUrl: string;
  source: 'LinkedIn' | 'JobStreet' | 'Other';
}