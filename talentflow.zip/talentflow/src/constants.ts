
import { JobProfile, Candidate, User, RoleDefinition, EmailTemplate, FormTemplate, Interview, SentForm, SeniorityLevel, RolePermissions, DepartmentInfo, ReportData, SystemAuditLog } from './types';

// Placeholder APIs from .env
export const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'https://webhook.n8n.placeholder.com';
export const API_KEY = process.env.REACT_APP_GEMINI_API_KEY || process.env.API_KEY || ''; // Google Gemini API Key

export const DEFAULT_DEPARTMENTS: DepartmentInfo[] = [
  { id: 'd1', name: 'HR' },
  { id: 'd2', name: 'Engineering' },
  { id: 'd3', name: 'Sales' },
  { id: 'd4', name: 'Marketing' },
  { id: 'd5', name: 'Product' }
];

export const PERMISSION_GROUPS: { category: string; permissions: { key: keyof RolePermissions; label: string }[] }[] = [
  {
    category: 'Job & Requisition Management',
    permissions: [
      { key: 'canCreateJobs', label: 'Create & Edit Job Requisitions' },
      { key: 'canApproveJobs', label: 'Approve Job Postings (Department Head)' }
    ]
  },
  {
    category: 'Candidate Pipeline Access',
    permissions: [
      { key: 'canViewAllCandidates', label: 'View All Candidates (Cross-Department)' },
      { key: 'canViewDepartmentCandidates', label: 'View Candidates (Own Dept Only)' },
      { key: 'canViewSensitiveData', label: 'View Sensitive Data (Salary/PII)' }
    ]
  },
  {
    category: 'Pipeline Workflow Actions',
    permissions: [
      { key: 'canShortlistCandidates', label: 'Shortlist Candidates (New -> Screening)' },
      { key: 'canAdvancePipelineStages', label: 'Advance Stages (Screening -> Interview -> Offer)' },
      { key: 'canProposeHiring', label: 'Propose to Hire (Offer -> Pending Approval)' },
      { key: 'canApproveHiring', label: 'Finalize Hire (Pending Approval -> Hired)' }
    ]
  },
  {
    category: 'System Administration',
    permissions: [
      { key: 'canManageUsers', label: 'Manage User Accounts & Roles' },
      { key: 'canConfigureWorkflows', label: 'Configure Workflows & Integrations' }
    ]
  }
];

export const DEFAULT_SENIORITY_LEVELS: SeniorityLevel[] = [
  { id: 's1', label: 'Intern', level: 1 },
  { id: 's2', label: 'Junior', level: 2 },
  { id: 's3', label: 'Mid-Level', level: 3 },
  { id: 's4', label: 'Senior', level: 4 },
  { id: 's5', label: 'Lead', level: 5 },
  { id: 's6', label: 'Manager', level: 6 },
  { id: 's7', label: 'Director', level: 7 },
  { id: 's8', label: 'Executive', level: 8 },
];

export const ROLE_DEFINITIONS: RoleDefinition[] = [
  {
    role: 'super_admin',
    label: 'Executive Director (Super Admin)',
    description: 'Ultimate authority. Can approve new roles and system-wide changes.',
    permissions: {
      canCreateJobs: true,
      canApproveJobs: true,
      canViewAllCandidates: true,
      canViewDepartmentCandidates: true,
      canManageUsers: true,
      canConfigureWorkflows: true,
      canViewSensitiveData: true,
      canShortlistCandidates: true,
      canAdvancePipelineStages: true,
      canProposeHiring: true,
      canApproveHiring: true
    }
  },
  {
    role: 'admin',
    label: 'Administrator',
    description: 'Full system access and configuration control.',
    permissions: {
      canCreateJobs: true,
      canApproveJobs: true,
      canViewAllCandidates: true,
      canViewDepartmentCandidates: true,
      canManageUsers: true,
      canConfigureWorkflows: true,
      canViewSensitiveData: true,
      canShortlistCandidates: true,
      canAdvancePipelineStages: true,
      canProposeHiring: true,
      canApproveHiring: true
    }
  },
  {
    role: 'approver',
    label: 'Department Head (Approver)',
    description: 'Can approve job requisitions and final hiring decisions.',
    permissions: {
      canCreateJobs: true,
      canApproveJobs: true,
      canViewAllCandidates: false,
      canViewDepartmentCandidates: true,
      canManageUsers: false,
      canConfigureWorkflows: false,
      canViewSensitiveData: true,
      canShortlistCandidates: true,
      canAdvancePipelineStages: true,
      canProposeHiring: true,
      canApproveHiring: true // Can approve the hire
    }
  },
  {
    role: 'verifier',
    label: 'Verifier (HR or Dept Lead)',
    description: 'Conducts screening, moves candidates through interviews and decision stages.',
    permissions: {
      canCreateJobs: false,
      canApproveJobs: false,
      canViewAllCandidates: false,
      canViewDepartmentCandidates: true,
      canManageUsers: false,
      canConfigureWorkflows: false,
      canViewSensitiveData: true,
      canShortlistCandidates: false, // Rule 1: Only requestor shortlists
      canAdvancePipelineStages: true,  // Rule 2: Verifier moves stages
      canProposeHiring: false,         // Rule 3: Only requestor proposes hire
      canApproveHiring: false
    }
  },
  {
    role: 'requestor',
    label: 'Requestor (Team Lead)',
    description: 'Requests new hires, shortlists applicants, and makes final hire proposals.',
    permissions: {
      canCreateJobs: true,
      canApproveJobs: false,
      canViewAllCandidates: false,
      canViewDepartmentCandidates: true,
      canManageUsers: false,
      canConfigureWorkflows: false,
      canViewSensitiveData: false,
      canShortlistCandidates: true,    // Rule 1
      canAdvancePipelineStages: false, // Rule 2: Cannot move middle stages
      canProposeHiring: true,          // Rule 3: Can propose
      canApproveHiring: false          // Cannot finalize
    }
  }
];

export const MOCK_USERS: User[] = [
  {
    id: 'u0',
    name: 'Alex Admin',
    email: 'admin@company.com',
    role: 'admin',
    department: 'HR',
    status: 'Active'
  },
  {
    id: 'u00',
    name: 'Eleanor Executive',
    email: 'ceo@company.com',
    role: 'super_admin',
    department: 'HR',
    status: 'Active'
  },
  {
    id: 'u1',
    name: 'Sarah Engineer',
    email: 'sarah@company.com',
    role: 'requestor',
    department: 'Engineering',
    status: 'Active'
  },
  {
    id: 'u2',
    name: 'Mike HR',
    email: 'mike.hr@company.com',
    role: 'verifier',
    department: 'HR',
    status: 'Active'
  },
  {
    id: 'u3',
    name: 'David Director',
    email: 'david.director@company.com',
    role: 'approver',
    department: 'Engineering',
    status: 'Active'
  },
  {
    id: 'u4',
    name: 'Jenny Tech Lead',
    email: 'jenny.tech@company.com',
    role: 'verifier',
    department: 'Engineering',
    status: 'Active'
  }
];

export const MOCK_JOBS: JobProfile[] = [
  {
    id: '1',
    title: 'Full-Stack Web Developer',
    department: 'Engineering',
    seniority: 'Mid-Level',
    description: 'We are looking for a full-stack web developer who knows how to use PHP, Python and Javascript.',
    requirements: ['PHP', 'Python', 'Javascript', 'React', 'Node.js'],
    certifications: ['AWS Certified Developer'],
    location: 'Northern Italy',
    createdAt: '2023-10-25',
    createdBy: 'u1',
    status: 'Active',
    evaluationCriteria: [
      { id: 'c1', category: 'Technical', description: 'Proficiency in Python backend frameworks', weight: 'high' },
      { id: 'c2', category: 'Experience', description: 'Previous work in Web Agencies', weight: 'medium' }
    ],
    assignedVerifier: 'Jenny Tech Lead',
    assignedApprover: 'David Director'
  },
  {
    id: '2',
    title: 'Senior Frontend Engineer',
    department: 'Engineering',
    seniority: 'Senior',
    description: 'Expert in React and TypeScript with a keen eye for UI/UX.',
    requirements: ['React', 'TypeScript', 'Tailwind', 'Figma'],
    certifications: [],
    location: 'Remote',
    createdAt: '2023-11-01',
    createdBy: 'u1',
    status: 'Pending Approval',
    evaluationCriteria: [
      { id: 'c3', category: 'Technical', description: 'Deep understanding of React internals', weight: 'high' },
      { id: 'c4', category: 'Soft Skills', description: 'Mentorship capability', weight: 'medium' }
    ],
    assignedVerifier: 'Jenny Tech Lead',
    assignedApprover: 'David Director'
  },
  {
    id: '3',
    title: 'Sales Representative',
    department: 'Sales',
    seniority: 'Junior',
    description: 'Energetic sales rep for the DACH region.',
    requirements: ['German', 'English', 'Salesforce'],
    certifications: ['Salesforce Associate'],
    location: 'Berlin',
    createdAt: '2023-11-05',
    createdBy: 'u4',
    status: 'Draft',
    evaluationCriteria: []
  }
];

export const MOCK_CANDIDATES: Candidate[] = [
  {
    id: '101',
    referenceNumber: 'ENG-2023-089',
    name: 'Giulia Rossi',
    email: 'giulia.rossi@example.com',
    city: 'Milan',
    phone: '+39 333 1234567',
    jobId: '1',
    department: 'Engineering',
    skills: ['PHP', 'Laravel', 'Vue.js', 'MySQL'],
    educationSummary: 'Master in Computer Science at Politecnico di Milano.',
    jobHistorySummary: '3 years at WebAgencyIT as Backend Developer.',
    aiScore: 8,
    aiConsideration: 'Strong backend skills matching the PHP requirement. Lives in Milan (Northern Italy). Good fit.',
    status: 'Interview',
    submissionDate: '2023-11-10',
    previousApplicationDeclared: false,
    auditLogs: [
      { id: 'a1', action: 'Status Change', details: 'Changed from New to Reviewing', actorName: 'Mike HR', timestamp: '2023-11-10T10:00:00Z' },
      { id: 'a2', action: 'Email Sent', details: 'Initial Interview Invite sent', actorName: 'Mike HR', timestamp: '2023-11-11T14:30:00Z' }
    ],
    scorecards: [
      { 
        id: 'sc1', 
        interviewerName: 'Sarah Engineer', 
        overallRating: 4, 
        feedback: 'Good technical skills, slightly weak on databases.', 
        competencyScores: [{ criteriaId: 'c1', score: 4 }, { criteriaId: 'c2', score: 5 }],
        submittedAt: '2023-11-12T09:00:00Z'
      }
    ],
    attachments: []
  },
  {
    id: '102',
    referenceNumber: 'ENG-2023-092',
    name: 'Marco Bianchi',
    email: 'marco.b@example.com',
    city: 'Rome',
    phone: '+39 344 9876543',
    jobId: '1',
    department: 'Engineering',
    skills: ['Java', 'Spring Boot', 'Angular'],
    educationSummary: 'Bachelor in Informatics.',
    jobHistorySummary: 'Junior Dev at CorpTech.',
    aiScore: 4,
    aiConsideration: 'Lacks required PHP/Python experience. Location is Rome (Central Italy), not Northern Italy.',
    status: 'Rejected',
    submissionDate: '2023-11-12',
    previousApplicationDeclared: true,
    auditLogs: [
      { id: 'a3', action: 'Status Change', details: 'Changed from New to Rejected', actorName: 'Mike HR', timestamp: '2023-11-13T09:15:00Z' }
    ],
    attachments: []
  },
  {
    id: '103',
    referenceNumber: 'ENG-2023-104',
    name: 'Elena Verdi',
    email: 'elena.v@example.com',
    city: 'Turin',
    phone: '+39 322 5556667',
    jobId: '1',
    department: 'Engineering',
    skills: ['Python', 'Django', 'JavaScript', 'React'],
    educationSummary: 'Self-taught with multiple certifications.',
    jobHistorySummary: 'Freelance Full Stack Developer for 4 years.',
    aiScore: 9,
    aiConsideration: 'Excellent match for Python and JS. Location fits. Freelance experience suggests independence.',
    status: 'New',
    submissionDate: '2023-11-14',
    previousApplicationDeclared: false,
    auditLogs: [],
    attachments: []
  }
];

export const MOCK_EMAIL_TEMPLATES: EmailTemplate[] = [
  {
    id: 'et1',
    name: 'Initial Interview Invite',
    type: 'Invitation',
    subject: 'Interview Invitation - TalentFlow AI',
    body: 'Hi {{name}},\n\nWe were impressed by your profile and would like to invite you for an initial phone screening.\n\nPlease let us know your availability for the coming week.\n\nBest,\nHR Team'
  },
  {
    id: 'et2',
    name: 'Technical Assessment Invite',
    type: 'General',
    subject: 'Technical Assessment',
    body: 'Hi {{name}},\n\nAs a next step, we would like you to complete a brief technical assessment. Please follow the link below.\n\n[Link]\n\nBest regards,\nTalentFlow Team'
  },
  {
    id: 'et3',
    name: 'Standard Rejection',
    type: 'Rejection',
    subject: 'Update on your application',
    body: 'Dear {{name}},\n\nThank you for your interest. Unfortunately, we have decided to proceed with other candidates who more closely match our current requirements.\n\nWe wish you the best of luck.\n\nSincerely,\nHR Team'
  },
  {
    id: 'et4',
    name: 'Rejection with Job Title',
    type: 'Rejection',
    subject: 'Application Status: {{job_title}}',
    body: 'Dear {{name}},\n\nThank you for giving us the opportunity to consider your application for the {{job_title}} position.\n\nAfter careful consideration, we have decided to move forward with other candidates whose qualifications more closely align with our current needs.\n\nWe appreciate your interest in our company and wish you success in your job search.\n\nBest regards,\nTalentFlow HR'
  }
];

export const MOCK_FORM_TEMPLATES: FormTemplate[] = [
  {
    id: 'ft1',
    title: 'Pre-Screening Questionnaire',
    description: 'Basic questions about availability and work status.',
    questions: [
      { id: 'q1', type: 'text', label: 'What is your notice period?' },
      { id: 'q2', type: 'choice', label: 'Are you eligible to work in the EU?' }
    ]
  },
  {
    id: 'ft2',
    title: 'Technical Self-Assessment (Frontend)',
    description: 'Rate your skills in key frontend technologies.',
    questions: [
      { id: 'q1', type: 'rating', label: 'Rate your React expertise (1-10)' },
      { id: 'q2', type: 'rating', label: 'Rate your CSS/Tailwind expertise (1-10)' }
    ]
  }
];

export const MOCK_INTERVIEWS: Interview[] = [
  {
    id: 'i1',
    candidateId: '101',
    candidateName: 'Giulia Rossi',
    jobTitle: 'Full-Stack Web Developer',
    date: new Date(Date.now() + 86400000).toISOString(),
    type: 'Technical',
    interviewers: ['Sarah Engineer', 'Mike HR'],
    status: 'Scheduled',
    notes: 'Focus on PHP frameworks.',
    meetingLink: 'https://meet.google.com/abc-defg-hij'
  }
];

export const MOCK_SENT_FORMS: SentForm[] = [
  {
    id: 'sf1',
    formTemplateId: 'ft1',
    formTitle: 'Pre-Screening Questionnaire',
    candidateId: '101',
    sentDate: '2023-11-11',
    status: 'Completed'
  }
];

export const MOCK_REPORT_DATA: ReportData = {
  pipelineFunnel: [
    { stage: 'Applied', count: 145 },
    { stage: 'Screened', count: 89 },
    { stage: 'Interview', count: 45 },
    { stage: 'Offer', count: 12 },
    { stage: 'Hired', count: 8 }
  ],
  hiresOverTime: [
    { date: 'Jan', hires: 4 },
    { date: 'Feb', hires: 3 },
    { date: 'Mar', hires: 6 },
    { date: 'Apr', hires: 5 },
    { date: 'May', hires: 8 },
    { date: 'Jun', hires: 7 }
  ],
  departmentDistribution: [
    { name: 'Engineering', value: 45 },
    { name: 'Sales', value: 30 },
    { name: 'Marketing', value: 15 },
    { name: 'HR', value: 10 }
  ],
  seniorityDistribution: [
    { name: 'Junior', value: 35 },
    { name: 'Mid-Level', value: 45 },
    { name: 'Senior', value: 15 },
    { name: 'Lead', value: 5 }
  ],
  positionDistribution: [
    { name: 'Full-Stack Dev', value: 42 },
    { name: 'Sales Rep', value: 28 },
    { name: 'Product Owner', value: 12 },
    { name: 'Frontend Eng', value: 18 }
  ],
  timeToHire: 24,
  totalApplications: 289,
  offerAcceptanceRate: 85
};

export const MOCK_SYSTEM_LOGS: SystemAuditLog[] = [
  {
    id: 'l1',
    actorName: 'Eleanor Executive',
    action: 'Approved Role',
    target: 'Role: Data Analyst',
    details: 'Approved new role creation request',
    timestamp: '2023-11-20T09:00:00Z',
    ipAddress: '192.168.1.5'
  },
  {
    id: 'l2',
    actorName: 'Alex Admin',
    action: 'Updated User',
    target: 'User: Mike HR',
    details: 'Changed status to Active',
    timestamp: '2023-11-19T14:30:00Z',
    ipAddress: '10.0.0.12'
  },
  {
    id: 'l3',
    actorName: 'Sarah Engineer',
    action: 'Created Requisition',
    target: 'Job: Backend Dev',
    details: 'Submitted new requisition for approval',
    timestamp: '2023-11-18T11:15:00Z',
    ipAddress: '10.0.0.45'
  },
  {
    id: 'l4',
    actorName: 'Alex Admin',
    action: 'Added Department',
    target: 'Dept: Legal',
    details: 'Created new department',
    timestamp: '2023-11-15T16:20:00Z',
    ipAddress: '10.0.0.12'
  },
  {
    id: 'l5',
    actorName: 'System',
    action: 'Backup',
    target: 'Database',
    details: 'Daily automated backup completed',
    timestamp: '2023-11-20T00:00:00Z',
    ipAddress: '127.0.0.1'
  }
];
