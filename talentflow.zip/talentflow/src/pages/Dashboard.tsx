
import React, { useEffect, useState } from 'react';
import { StatCard } from '../components/StatCard';
import { Users, FileText, CheckCircle, TrendingUp, AlertCircle, Filter, Building2, Briefcase } from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { apiService } from '../services/apiService';
import { Candidate, JobProfile } from '../types';

export const Dashboard: React.FC = () => {
  const [allCandidates, setAllCandidates] = useState<Candidate[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [jobs, setJobs] = useState<JobProfile[]>([]);
  
  // Filtering State
  const [analysisLevel, setAnalysisLevel] = useState<'Company' | 'Department' | 'Position'>('Company');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedJobId, setSelectedJobId] = useState<string>('All');

  useEffect(() => {
    Promise.all([
      apiService.getCandidates(),
      apiService.getJobs()
    ]).then(([cData, jData]) => {
      setAllCandidates(cData);
      setCandidates(cData);
      setJobs(jData);
    });
  }, []);

  // Apply filters whenever selection changes
  useEffect(() => {
    let filtered = [...allCandidates];

    if (analysisLevel === 'Department' && selectedDept !== 'All') {
      filtered = filtered.filter(c => c.department === selectedDept);
    } else if (analysisLevel === 'Position' && selectedJobId !== 'All') {
      filtered = filtered.filter(c => c.jobId === selectedJobId);
    }

    setCandidates(filtered);
  }, [analysisLevel, selectedDept, selectedJobId, allCandidates]);

  // Compute stats
  const total = candidates.length;
  const avgScore = candidates.reduce((acc, curr) => acc + curr.aiScore, 0) / (total || 1);
  const hired = candidates.filter(c => c.status === 'Hired').length;
  
  const statusData = [
    { name: 'New', value: candidates.filter(c => c.status === 'New').length, color: '#6366f1' },
    { name: 'Review', value: candidates.filter(c => c.status === 'Reviewing').length, color: '#f59e0b' },
    { name: 'Interview', value: candidates.filter(c => c.status === 'Interview').length, color: '#10b981' },
    { name: 'Rejected', value: candidates.filter(c => c.status === 'Rejected').length, color: '#ef4444' },
  ];

  const scoreData = candidates.map(c => ({
    name: c.name.split(' ')[0], // First name
    score: c.aiScore
  }));

  // Unique Departments
  const departments = Array.from(new Set(jobs.map(j => j.department)));

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500 mt-1">Real-time insights from your recruitment pipeline.</p>
        </div>

        {/* Analysis Filters */}
        <div className="flex flex-wrap items-center gap-3 bg-white p-2 rounded-lg border border-slate-200 shadow-sm">
           <div className="flex items-center gap-2 px-2 text-sm text-slate-500 font-medium">
             <Filter className="w-4 h-4" /> Analyze by:
           </div>
           
           <div className="flex gap-2">
             <button 
               onClick={() => { setAnalysisLevel('Company'); setSelectedDept('All'); setSelectedJobId('All'); }}
               className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${analysisLevel === 'Company' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
             >
               Company
             </button>
             <button 
               onClick={() => { setAnalysisLevel('Department'); setSelectedJobId('All'); if(selectedDept === 'All') setSelectedDept(departments[0] || 'All'); }}
               className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${analysisLevel === 'Department' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
             >
               Department
             </button>
             <button 
               onClick={() => { setAnalysisLevel('Position'); setSelectedDept('All'); if(selectedJobId === 'All') setSelectedJobId(jobs[0]?.id || 'All'); }}
               className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${analysisLevel === 'Position' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
             >
               Position
             </button>
           </div>

           {/* Dynamic Dropdowns based on Level */}
           {analysisLevel === 'Department' && (
             <div className="border-l border-slate-200 pl-3">
               <select 
                  className="text-xs border-slate-200 rounded-md py-1 pr-8 text-slate-700 focus:ring-indigo-500 focus:border-indigo-500"
                  value={selectedDept}
                  onChange={(e) => setSelectedDept(e.target.value)}
                >
                  {departments.map(d => <option key={d} value={d}>{d}</option>)}
               </select>
             </div>
           )}

           {analysisLevel === 'Position' && (
             <div className="border-l border-slate-200 pl-3">
                <select 
                  className="text-xs border-slate-200 rounded-md py-1 pr-8 text-slate-700 focus:ring-indigo-500 focus:border-indigo-500"
                  value={selectedJobId}
                  onChange={(e) => setSelectedJobId(e.target.value)}
                >
                  {jobs.map(j => <option key={j.id} value={j.id}>{j.title}</option>)}
               </select>
             </div>
           )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Candidates" value={total} icon={Users} trend="+12%" trendUp={true} />
        <StatCard title="Average AI Score" value={avgScore.toFixed(1)} icon={TrendingUp} trend="+0.4" trendUp={true} />
        <StatCard title="Hired this Month" value={hired} icon={CheckCircle} />
        <StatCard title="Pending Review" value={candidates.filter(c => c.status === 'New').length} icon={AlertCircle} trend="-2" trendUp={true} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Score Distribution Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Candidate AI Scores</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scoreData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fill: '#64748b' }} axisLine={false} />
                <YAxis tick={{ fill: '#64748b' }} axisLine={false} domain={[0, 10]} />
                <Tooltip 
                  cursor={{ fill: '#f1f5f9' }}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="score" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Distribution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Pipeline Status</h3>
          <div className="h-80 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={110}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute flex flex-col items-center justify-center pointer-events-none">
              <span className="text-3xl font-bold text-slate-800">{total}</span>
              <span className="text-sm text-slate-500">Applications</span>
            </div>
          </div>
          <div className="flex justify-center gap-4 mt-4">
            {statusData.map((entry) => (
              <div key={entry.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
                <span className="text-sm text-slate-600">{entry.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
