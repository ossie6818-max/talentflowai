
import React, { useEffect, useState } from 'react';
import { apiService } from '../services/apiService';
import { geminiService } from '../services/geminiService';
import { ReportData, ReportFilter } from '../types';
import { DEFAULT_DEPARTMENTS, MOCK_JOBS, DEFAULT_SENIORITY_LEVELS } from '../constants';
import { Printer, Filter, Sparkles, Bot, FileText } from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area, PieChart, Pie, Cell, Legend
} from 'recharts';

export const Reports: React.FC = () => {
  const [data, setData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Main Data Filter
  const [filter, setFilter] = useState<ReportFilter>({
    dateRange: 'quarter',
    department: 'All',
    reportType: 'pipeline'
  });

  // AI Analysis State
  const [aiNarrative, setAiNarrative] = useState('');
  const [isGeneratingNarrative, setIsGeneratingNarrative] = useState(false);
  const [aiScope, setAiScope] = useState<'Companywide' | 'Department' | 'Position' | 'Seniority'>('Companywide');
  const [aiTarget, setAiTarget] = useState('All');
  const [aiPeriod, setAiPeriod] = useState('This Quarter');

  useEffect(() => {
    setLoading(true);
    apiService.getReports(filter).then((res) => {
      setData(res);
      setLoading(false);
    });
  }, [filter]);

  const handlePrint = () => {
    window.print();
  };

  const handleGenerateAnalysis = async () => {
    if (!data) return;
    setIsGeneratingNarrative(true);
    const narrative = await geminiService.generateReportNarrative(data, aiScope, aiPeriod, aiTarget);
    setAiNarrative(narrative);
    setIsGeneratingNarrative(false);
  };

  const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f97316', '#14b8a6', '#84cc16'];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-6 print:space-y-4">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 print:hidden">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Analysis & Reports</h1>
          <p className="text-slate-500 mt-1">Recruitment analytics, pipeline insights, and AI-driven executive summaries.</p>
        </div>
        <div className="flex gap-3">
          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
             <Filter className="w-4 h-4 text-slate-400" />
             <select 
               className="text-sm border-none focus:ring-0 text-slate-700 bg-transparent p-0 cursor-pointer"
               value={filter.dateRange}
               onChange={(e) => setFilter({...filter, dateRange: e.target.value as any})}
             >
               <option value="week">This Week</option>
               <option value="month">This Month</option>
               <option value="quarter">This Quarter</option>
               <option value="year">This Year</option>
             </select>
          </div>
          <button 
             onClick={handlePrint}
             className="flex items-center gap-2 bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-lg font-medium hover:bg-slate-50 shadow-sm transition-colors"
          >
            <Printer className="w-4 h-4" /> Print Report
          </button>
        </div>
      </div>

      {/* AI Analysis Generator Section */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-100 p-6 shadow-sm break-inside-avoid print:break-inside-avoid">
        <div className="flex items-center gap-2 mb-4">
           <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-sm">
              <Sparkles className="w-5 h-5" />
           </div>
           <h3 className="text-lg font-bold text-indigo-900">AI Executive Analysis</h3>
        </div>
        
        <p className="text-sm text-indigo-700 mb-6 max-w-3xl">
          Generate a narrative report using Gemini AI based on the statistical data below. Select your parameters to customize the insight.
        </p>
        
        {/* Selection Controls */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4 print:hidden">
           <div>
              <label className="block text-xs font-semibold text-indigo-800 uppercase mb-1">Analysis Scope</label>
              <select 
                value={aiScope}
                onChange={(e) => { setAiScope(e.target.value as any); setAiTarget('All'); }}
                className="w-full text-sm border-indigo-200 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 bg-white"
              >
                <option value="Companywide">Companywide</option>
                <option value="Department">By Department</option>
                <option value="Position">By Position</option>
                <option value="Seniority">By Seniority</option>
              </select>
           </div>

           {aiScope !== 'Companywide' && (
             <div className="animate-fadeIn">
               <label className="block text-xs font-semibold text-indigo-800 uppercase mb-1">Target</label>
               <select 
                 value={aiTarget}
                 onChange={(e) => setAiTarget(e.target.value)}
                 className="w-full text-sm border-indigo-200 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 bg-white"
               >
                 <option value="All">Select Target...</option>
                 {aiScope === 'Department' && DEFAULT_DEPARTMENTS.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
                 {aiScope === 'Position' && MOCK_JOBS.map(j => <option key={j.id} value={j.title}>{j.title}</option>)}
                 {aiScope === 'Seniority' && DEFAULT_SENIORITY_LEVELS.map(s => <option key={s.id} value={s.label}>{s.label}</option>)}
               </select>
             </div>
           )}

           <div>
              <label className="block text-xs font-semibold text-indigo-800 uppercase mb-1">Cover Period</label>
              <select 
                value={aiPeriod}
                onChange={(e) => setAiPeriod(e.target.value)}
                className="w-full text-sm border-indigo-200 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 bg-white"
              >
                <option value="This Week">This Week</option>
                <option value="This Month">This Month</option>
                <option value="This Quarter">This Quarter</option>
                <option value="Year to Date">Year to Date</option>
                <option value="Last Year">Last Year</option>
              </select>
           </div>

           <div className="flex items-end">
              <button 
                onClick={handleGenerateAnalysis}
                disabled={isGeneratingNarrative}
                className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-indigo-700 shadow-sm flex items-center justify-center gap-2 disabled:opacity-70 transition-all"
              >
                {isGeneratingNarrative ? <Bot className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {isGeneratingNarrative ? 'Analyzing Data...' : 'Generate Narrative'}
              </button>
           </div>
        </div>

        {/* Narrative Output */}
        {aiNarrative ? (
           <div className="bg-white p-6 rounded-lg border border-indigo-100 shadow-sm animate-fadeIn relative">
              <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-2">
                 <h4 className="font-bold text-slate-800 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-slate-500" /> 
                    Executive Summary: {aiScope === 'Companywide' ? 'Company Performance' : aiTarget}
                 </h4>
                 <span className="text-xs text-slate-400 font-mono">Generated by Gemini AI</span>
              </div>
              <div className="prose prose-sm text-slate-600 max-w-none whitespace-pre-wrap leading-relaxed">
                 {aiNarrative}
              </div>
           </div>
        ) : (
           <div className="hidden print:hidden text-center py-4 text-indigo-400 text-sm italic border border-dashed border-indigo-200 rounded-lg bg-indigo-50/50">
              Select parameters above and click "Generate Narrative" to see AI insights.
           </div>
        )}
      </div>

      {/* Print Header (Only visible when printing) */}
      <div className="hidden print:block mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Analysis & Reports</h1>
        <p className="text-slate-500">Generated on {new Date().toLocaleDateString()}</p>
        <div className="mt-4 flex gap-4 text-sm text-slate-600 border-t border-b border-slate-200 py-2">
           <span><strong>Period:</strong> {filter.dateRange.toUpperCase()}</span>
           <span><strong>Department:</strong> {filter.department}</span>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 print:grid-cols-3">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
           <p className="text-sm font-medium text-slate-500">Time to Hire (Avg)</p>
           <p className="text-3xl font-bold text-slate-900 mt-2">{data.timeToHire} <span className="text-sm font-normal text-slate-400">days</span></p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
           <p className="text-sm font-medium text-slate-500">Total Applications</p>
           <p className="text-3xl font-bold text-slate-900 mt-2">{data.totalApplications}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
           <p className="text-sm font-medium text-slate-500">Offer Acceptance Rate</p>
           <p className="text-3xl font-bold text-slate-900 mt-2">{data.offerAcceptanceRate}%</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 print:grid-cols-2 print:gap-4">
         {/* Funnel Chart */}
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 break-inside-avoid min-h-[300px]">
            <h3 className="font-bold text-slate-800 mb-6">Pipeline Funnel</h3>
            <div className="h-64 w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <BarChart data={data.pipelineFunnel} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                    <XAxis type="number" hide />
                    <YAxis dataKey="stage" type="category" width={80} tick={{fontSize: 12}} />
                    <Tooltip cursor={{fill: '#f8fafc'}} />
                    <Bar dataKey="count" fill="#6366f1" radius={[0, 4, 4, 0]} barSize={30}>
                       {data.pipelineFunnel.map((entry, index) => (
                         <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                       ))}
                    </Bar>
                 </BarChart>
               </ResponsiveContainer>
            </div>
         </div>

         {/* Department Dist Chart */}
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 break-inside-avoid min-h-[300px]">
            <h3 className="font-bold text-slate-800 mb-6">Applications by Department</h3>
            <div className="h-64 w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                    <Pie
                      data={data.departmentDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {data.departmentDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                 </PieChart>
               </ResponsiveContainer>
            </div>
         </div>

         {/* Seniority Distribution */}
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 break-inside-avoid min-h-[300px]">
            <h3 className="font-bold text-slate-800 mb-6">Applicants by Seniority Level</h3>
            <div className="h-64 w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                    <Pie
                      data={data.seniorityDistribution}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {data.seniorityDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[(index + 2) % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                 </PieChart>
               </ResponsiveContainer>
            </div>
         </div>

         {/* Position Distribution */}
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 break-inside-avoid min-h-[300px]">
            <h3 className="font-bold text-slate-800 mb-6">Applications by Position</h3>
            <div className="h-64 w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <BarChart data={data.positionDistribution} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                    <XAxis type="number" hide />
                    <YAxis dataKey="name" type="category" width={110} tick={{fontSize: 11}} />
                    <Tooltip cursor={{fill: '#f8fafc'}} />
                    <Bar dataKey="value" fill="#14b8a6" radius={[0, 4, 4, 0]} barSize={20} />
                 </BarChart>
               </ResponsiveContainer>
            </div>
         </div>

         {/* Hires Trend */}
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 lg:col-span-2 break-inside-avoid min-h-[300px]">
            <h3 className="font-bold text-slate-800 mb-6">Hiring Trend (Last 6 Months)</h3>
            <div className="h-64 w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={data.hiresOverTime}>
                    <defs>
                      <linearGradient id="colorHires" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="date" tick={{fontSize: 12}} />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="hires" stroke="#6366f1" fillOpacity={1} fill="url(#colorHires)" />
                 </AreaChart>
               </ResponsiveContainer>
            </div>
         </div>
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden break-inside-avoid print:border-slate-300">
         <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
            <h3 className="font-bold text-slate-800">Raw Metric Data</h3>
         </div>
         <table className="min-w-full divide-y divide-slate-200 text-sm">
            <thead className="bg-slate-50">
               <tr>
                  <th className="px-6 py-3 text-left font-medium text-slate-500 uppercase tracking-wider">Metric</th>
                  <th className="px-6 py-3 text-left font-medium text-slate-500 uppercase tracking-wider">Value</th>
                  <th className="px-6 py-3 text-left font-medium text-slate-500 uppercase tracking-wider">Change</th>
               </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
               <tr>
                  <td className="px-6 py-4 font-medium text-slate-900">Total Applicants</td>
                  <td className="px-6 py-4 text-slate-600">{data.totalApplications}</td>
                  <td className="px-6 py-4 text-green-600 font-medium">+12%</td>
               </tr>
               <tr>
                  <td className="px-6 py-4 font-medium text-slate-900">Avg Time to Hire</td>
                  <td className="px-6 py-4 text-slate-600">{data.timeToHire} days</td>
                  <td className="px-6 py-4 text-red-500 font-medium">+2 days</td>
               </tr>
               <tr>
                  <td className="px-6 py-4 font-medium text-slate-900">Offer Acceptance</td>
                  <td className="px-6 py-4 text-slate-600">{data.offerAcceptanceRate}%</td>
                  <td className="px-6 py-4 text-slate-400">0%</td>
               </tr>
            </tbody>
         </table>
      </div>
    </div>
  );
};